Vous pouvez stocker les images de votre thèse dans le présent répertoire.
